package com.itdemo.gulimail.search.constant;

public class Esconstant {
    public static final String PRODUCT_INDEX="product";
}
